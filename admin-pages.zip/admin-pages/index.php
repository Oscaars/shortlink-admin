<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Admin Shortlink</title>
  <link rel="stylesheet" href="/style.css">
</head>
<body>
  <div class="wrap">
    <h1>Admin Shortlink</h1>
    <p class="muted">Daftar/Login untuk kelola shortlink. Setelah login, kamu dapat API Key.</p>

    <div class="card">
      <label>Email</label>
      <input id="email" placeholder="email@domain.com">
      <label>Password</label>
      <input id="pass" type="password" placeholder="min 6 karakter">

      <div class="row">
        <button onclick="registerUser()">Daftar</button>
        <button class="primary" onclick="loginUser()">Login</button>
      </div>

      <div id="msg" class="msg"></div>
    </div>
  </div>

  <script src="/app.js"></script>
</body>
</html>
