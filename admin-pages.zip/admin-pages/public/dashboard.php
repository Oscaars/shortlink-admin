<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Dashboard</title>
  <link rel="stylesheet" href="/style.css">
</head>
<body onload="bootDashboard()">
  <div class="wrap">
    <div class="top">
      <h1>Dashboard</h1>
      <button onclick="logout()">Logout</button>
    </div>

    <div class="card">
      <div class="row-between">
        <div>
          <div class="muted">API Key kamu (untuk kontrol shortlink via API):</div>
          <div class="apikey" id="apikey">-</div>
        </div>
        <button class="warn" onclick="regenApiKey()">Regenerate</button>
      </div>
      <div class="muted small">Simpan API Key baik-baik. Kalau regenerate, key lama langsung tidak berlaku.</div>
    </div>

    <div class="card">
      <h2>Buat / Update Shortlink</h2>
      <label>Slug</label>
      <input id="slug" placeholder="contoh: promo">
      <label>Target URL</label>
      <input id="target" placeholder="contoh: https://google.com">
      <div class="row">
        <button class="primary" onclick="saveLink()">Simpan</button>
        <button onclick="loadLinks()">Refresh List</button>
      </div>
      <div id="msg2" class="msg"></div>
    </div>

    <div class="card">
      <h2>Daftar Shortlink</h2>
      <div id="list" class="list muted">Loading...</div>
    </div>

    <div class="card">
      <h2>Contoh pakai API Key (curl)</h2>
      <pre id="curlEx"></pre>
    </div>
  </div>

  <script src="/app.js"></script>
</body>
</html>
