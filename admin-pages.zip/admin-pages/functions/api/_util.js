// PBKDF2 SHA-256 (lebih aman daripada sha256 doang) + salt
const enc = new TextEncoder();

function b64u(bytes) {
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
}
function b64uToBytes(s){
  s = s.replace(/-/g,"+").replace(/_/g,"/");
  const pad = s.length % 4 ? "=".repeat(4 - (s.length % 4)) : "";
  const bin = atob(s + pad);
  return Uint8Array.from(bin, c => c.charCodeAt(0));
}

export async function hashPassword(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name:"PBKDF2", hash:"SHA-256", salt, iterations: 120000 },
    key,
    256
  );
  const hash = new Uint8Array(bits);
  return `pbkdf2$120000$${b64u(salt)}$${b64u(hash)}`;
}

export async function verifyPassword(password, stored) {
  const parts = stored.split("$");
  if (parts.length !== 5 || parts[0] !== "pbkdf2") return false;
  const iters = parseInt(parts[1], 10);
  const salt = b64uToBytes(parts[3]);
  const expected = parts[4];

  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name:"PBKDF2", hash:"SHA-256", salt, iterations: iters },
    key,
    256
  );
  const got = b64u(new Uint8Array(bits));
  return got === expected;
}

export function makeApiKey() {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  return "sk_" + b64u(bytes);
}

export function json(obj, status=200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      "Content-Type":"application/json; charset=utf-8",
      "Cache-Control":"no-store, no-cache, must-revalidate, max-age=0",
      "Pragma":"no-cache",
      "Expires":"0",
    }
  });
}

export function getApiKey(request) {
  return request.headers.get("X-API-Key") || "";
}
