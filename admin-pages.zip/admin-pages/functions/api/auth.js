import { hashPassword, verifyPassword, makeApiKey, json } from "./_util.js";

export async function onRequestPost({ request, env }) {
  const body = await request.json().catch(()=>null);
  const type = body?.type;
  const email = (body?.email || "").trim().toLowerCase();
  const password = body?.password || "";

  if (!email || !email.includes("@")) return json({ ok:false, error:"Email tidak valid." }, 400);
  if (password.length < 6) return json({ ok:false, error:"Password minimal 6 karakter." }, 400);

  if (type === "register") {
    const pass = await hashPassword(password);
    const apiKey = makeApiKey();
    try {
      await env.DB.prepare(
        "INSERT INTO users (email, pass, api_key, created_at) VALUES (?, ?, ?, datetime('now'))"
      ).bind(email, pass, apiKey).run();
      return json({ ok:true });
    } catch {
      return json({ ok:false, error:"Email sudah terdaftar." }, 409);
    }
  }

  if (type === "login") {
    const u = await env.DB.prepare("SELECT id, email, pass, api_key FROM users WHERE email=?")
      .bind(email).first();

    if (!u) return json({ ok:false, error:"Email/password salah." }, 401);
    const ok = await verifyPassword(password, u.pass);
    if (!ok) return json({ ok:false, error:"Email/password salah." }, 401);

    return json({ ok:true, user:{ id:u.id, email:u.email, api_key:u.api_key } });
  }

  return json({ ok:false, error:"Bad request" }, 400);
}
