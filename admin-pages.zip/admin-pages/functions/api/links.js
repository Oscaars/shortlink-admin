import { json, getApiKey } from "./_util.js";

function normUrl(x){
  x = (x || "").trim();
  if (!x) return "";
  if (!/^https?:\/\//i.test(x)) x = "https://" + x;
  return x;
}

export async function onRequestGet({ request, env }) {
  const key = getApiKey(request);
  const u = await env.DB.prepare("SELECT id FROM users WHERE api_key=?").bind(key).first();
  if (!u) return json({ ok:false, error:"Invalid API key" }, 401);

  const rows = await env.DB.prepare(
    "SELECT slug, target, updated_at FROM links WHERE user_id=? ORDER BY updated_at DESC"
  ).bind(u.id).all();

  return json({ ok:true, links: rows.results || [] });
}

export async function onRequestPost({ request, env }) {
  const key = getApiKey(request);
  const u = await env.DB.prepare("SELECT id FROM users WHERE api_key=?").bind(key).first();
  if (!u) return json({ ok:false, error:"Invalid API key" }, 401);

  const body = await request.json().catch(()=>null);
  const slug = (body?.slug || "").trim();
  const target = normUrl(body?.target || "");

  if (!/^[a-zA-Z0-9_-]{2,64}$/.test(slug)) return json({ ok:false, error:"Slug invalid (2-64, a-zA-Z0-9_-)" }, 400);
  if (!target) return json({ ok:false, error:"Target URL wajib diisi" }, 400);

  // Simpan ke D1
  await env.DB.prepare(`
    INSERT INTO links (user_id, slug, target, created_at, updated_at)
    VALUES (?, ?, ?, datetime('now'), datetime('now'))
    ON CONFLICT(slug) DO UPDATE SET
      target=excluded.target,
      updated_at=datetime('now')
  `).bind(u.id, slug, target).run();

  // Sync ke KV untuk redirect publik (langsung aktif)
  await env.SHORTLINK_KV.put(slug, target);

  return json({ ok:true, slug, target });
}

export async function onRequestDelete({ request, env }) {
  const key = getApiKey(request);
  const u = await env.DB.prepare("SELECT id FROM users WHERE api_key=?").bind(key).first();
  if (!u) return json({ ok:false, error:"Invalid API key" }, 401);

  const body = await request.json().catch(()=>null);
  const slug = (body?.slug || "").trim();
  if (!/^[a-zA-Z0-9_-]{2,64}$/.test(slug)) return json({ ok:false, error:"Slug invalid" }, 400);

  await env.DB.prepare("DELETE FROM links WHERE user_id=? AND slug=?").bind(u.id, slug).run();
  await env.SHORTLINK_KV.delete(slug);

  return json({ ok:true, deleted: slug });
}
