import { makeApiKey, json, getApiKey } from "./_util.js";

export async function onRequestPost({ request, env }) {
  const oldKey = getApiKey(request);
  if (!oldKey) return json({ ok:false, error:"Missing API key" }, 401);

  const u = await env.DB.prepare("SELECT id FROM users WHERE api_key=?").bind(oldKey).first();
  if (!u) return json({ ok:false, error:"Invalid API key" }, 401);

  const newKey = makeApiKey();
  await env.DB.prepare("UPDATE users SET api_key=? WHERE id=?").bind(newKey, u.id).run();

  return json({ ok:true, api_key:newKey });
}
