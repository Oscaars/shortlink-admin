function setMsg(id, text, ok=false){
  const el = document.getElementById(id);
  if(!el) return;
  el.textContent = text || "";
  el.style.color = ok ? "#7CFFB2" : "#FF8A8A";
}

function getUser(){
  try { return JSON.parse(localStorage.getItem("sl_user") || "null"); }
  catch { return null; }
}
function setUser(u){
  localStorage.setItem("sl_user", JSON.stringify(u));
}
function requireUser(){
  const u = getUser();
  if(!u || !u.api_key){
    location.href = "/index.php";
    return null;
  }
  return u;
}

async function registerUser(){
  setMsg("msg","",true);
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("pass").value;
  const res = await fetch("/api/auth", {
    method:"POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({ type:"register", email, password })
  });
  const d = await res.json().catch(()=>({}));
  if(res.ok && d.ok){
    setMsg("msg","Register sukses. Silakan login.", true);
  } else {
    setMsg("msg", d.error || "Register gagal.");
  }
}

async function loginUser(){
  setMsg("msg","",true);
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("pass").value;
  const res = await fetch("/api/auth", {
    method:"POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({ type:"login", email, password })
  });
  const d = await res.json().catch(()=>({}));
  if(res.ok && d.ok){
    setUser(d.user);
    location.href = "/dashboard.php";
  } else {
    setMsg("msg", d.error || "Login gagal.");
  }
}

function logout(){
  localStorage.removeItem("sl_user");
  location.href = "/index.php";
}

async function bootDashboard(){
  const u = requireUser(); if(!u) return;
  document.getElementById("apikey").textContent = u.api_key;

  const curl = `curl -X POST "https://admin.${location.host.split('.').slice(-2).join('.')}/api/links" \\
  -H "Content-Type: application/json" \\
  -H "X-API-Key: ${u.api_key}" \\
  -d '{"slug":"promo","target":"https://google.com"}'`;
  document.getElementById("curlEx").textContent = curl;

  await loadLinks();
}

async function regenApiKey(){
  const u = requireUser(); if(!u) return;
  const res = await fetch("/api/apikey", {
    method:"POST",
    headers: {"Content-Type":"application/json","X-API-Key": u.api_key}
  });
  const d = await res.json().catch(()=>({}));
  if(res.ok && d.ok){
    u.api_key = d.api_key;
    setUser(u);
    document.getElementById("apikey").textContent = u.api_key;
    setMsg("msg2","API Key berhasil diganti.", true);
  } else {
    setMsg("msg2", d.error || "Gagal regenerate API key.");
  }
}

async function saveLink(){
  const u = requireUser(); if(!u) return;
  const slug = document.getElementById("slug").value.trim();
  const target = document.getElementById("target").value.trim();

  const res = await fetch("/api/links", {
    method:"POST",
    headers: {"Content-Type":"application/json","X-API-Key": u.api_key},
    body: JSON.stringify({ slug, target })
  });
  const d = await res.json().catch(()=>({}));
  if(res.ok && d.ok){
    setMsg("msg2", `OK: /${slug} aktif di domain utama`, true);
    await loadLinks();
  } else {
    setMsg("msg2", d.error || "Gagal simpan link.");
  }
}

async function delLink(slug){
  const u = requireUser(); if(!u) return;
  if(!confirm(`Hapus /${slug}?`)) return;

  const res = await fetch("/api/links", {
    method:"DELETE",
    headers: {"Content-Type":"application/json","X-API-Key": u.api_key},
    body: JSON.stringify({ slug })
  });
  const d = await res.json().catch(()=>({}));
  if(res.ok && d.ok){
    setMsg("msg2", `Deleted: /${slug}`, true);
    await loadLinks();
  } else {
    setMsg("msg2", d.error || "Gagal hapus link.");
  }
}

async function loadLinks(){
  const u = requireUser(); if(!u) return;
  const res = await fetch("/api/links", { headers: {"X-API-Key": u.api_key} });
  const d = await res.json().catch(()=>({}));
  const list = document.getElementById("list");
  if(!res.ok || !d.ok){
    list.textContent = d.error || "Gagal load list.";
    return;
  }
  if(!d.links.length){
    list.textContent = "Belum ada shortlink.";
    return;
  }
  list.innerHTML = d.links.map(x => `
    <div class="item">
      <div><span class="mono">/${x.slug}</span> → <span class="mono">${x.target}</span></div>
      <div class="muted small">Update: ${x.updated_at}</div>
      <div class="actions">
        <button onclick="navigator.clipboard.writeText('https://${document.domain.replace('admin.','')}/${x.slug}')">Copy URL publik</button>
        <button class="warn" onclick="delLink('${x.slug}')">Hapus</button>
      </div>
    </div>
  `).join("");
}
